package co.conexia.test.restaurant.vista;

import java.util.List;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.context.FacesContext;

import org.primefaces.component.commandbutton.CommandButton;
import org.primefaces.component.inputtext.InputText;
import org.primefaces.component.selectonemenu.SelectOneMenu;

import co.conexia.test.restaurant.modelo.Cliente;

@ManagedBean
public class ClienteVista {
	
	@ManagedProperty("#{delegadoDeNegocio}")
	private IDelegadoDeNegocio delegadoDeNegocio;	
	
	private List<Cliente> listaClientes;
	
	private InputText txtNombre;
	private InputText txtApellido1;
	private InputText txtApellido2;
	private InputText txtObservaciones;		
	private InputText txtPlato;
	private InputText txtImporte;
	
	private CommandButton btnCrear;
	private CommandButton btnModificar;	
	private CommandButton btnLimpiar;

	public List<Cliente> getListaClientes() {
		if(listaClientes==null) {
			listaClientes = delegadoDeNegocio.consultarClienteTodos();
		}
		return listaClientes;
	}

	public void setListaClientes(List<Cliente> listaClientes) {
		this.listaClientes = listaClientes;
	}

	public IDelegadoDeNegocio getDelegadoDeNegocio() {
		return delegadoDeNegocio;
	}

	public void setDelegadoDeNegocio(IDelegadoDeNegocio delegadoDeNegocio) {
		this.delegadoDeNegocio = delegadoDeNegocio;
	}
	
    public String crearAction() {
		
		try {		
			
			Cliente cliente=new Cliente();
			
			cliente.setNombre(txtNombre.getValue().toString());
			cliente.setApellido1(txtApellido1.getValue().toString());
			cliente.setApellido2(txtApellido2.getValue().toString());
			cliente.setObservaciones(txtObservaciones.getValue().toString());
			
			delegadoDeNegocio.grabarCliente(cliente);
			
			FacesMessage facesMessage=new FacesMessage(FacesMessage.SEVERITY_INFO, "El cliente se creo con exito", "");
			FacesContext.getCurrentInstance().addMessage("", facesMessage);
		} catch (Exception e) {
			FacesMessage facesMessage=new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), "");
			FacesContext.getCurrentInstance().addMessage("", facesMessage);
		}
		return "";
	}
	
	public String modificarAction() {
		try {			
			
			Cliente cliente=new Cliente();
			cliente.setNombre(txtNombre.getValue().toString());
			cliente.setApellido1(txtApellido1.getValue().toString());
			cliente.setApellido2(txtApellido2.getValue().toString());
			cliente.setObservaciones(txtObservaciones.getValue().toString());			
			
			delegadoDeNegocio.modificarCliente(cliente);
			
			FacesMessage facesMessage=new FacesMessage(FacesMessage.SEVERITY_INFO, "El cliente se modific� con exito", "");
			FacesContext.getCurrentInstance().addMessage("", facesMessage);
		} catch (Exception e) {
			FacesMessage facesMessage=new FacesMessage(FacesMessage.SEVERITY_ERROR, e.getMessage(), "");
			FacesContext.getCurrentInstance().addMessage("", facesMessage);
		}
		return "";
	}
	
	public String limpiarAction() {
		txtNombre.resetValue();
		txtApellido1.resetValue();
		txtApellido2.resetValue();
		txtObservaciones.resetValue();		
		
		btnCrear.setDisabled(true);
		btnModificar.setDisabled(true);		
		
		return "";
	}
	
	public InputText getTxtNombre() {
		return txtNombre;
	}

	public void setTxtNombre(InputText txtNombre) {
		this.txtNombre = txtNombre;
	}
	
	public InputText getTxtApellido1() {
		return txtApellido1;
	}

	public void setTxtApellido1(InputText txtApellido1) {
		this.txtApellido1 = txtApellido1;
	}
	
	public InputText getTxtApellido2() {
		return txtApellido2;
	}

	public void setTxtApellido2(InputText txtApellido2) {
		this.txtApellido2 = txtApellido2;
	}
	
	public InputText getTxtObservaciones() {
		return txtObservaciones;
	}

	public void setTxtObservaciones(InputText txtObservaciones) {
		this.txtObservaciones = txtObservaciones;
	}
	
	public CommandButton getBtnCrear() {
		return btnCrear;
	}

	public void setBtnCrear(CommandButton btnCrear) {
		this.btnCrear = btnCrear;
	}

	public CommandButton getBtnModificar() {
		return btnModificar;
	}

	public void setBtnModificar(CommandButton btnModificar) {
		this.btnModificar = btnModificar;
	}	

	public CommandButton getBtnLimpiar() {
		return btnLimpiar;
	}

	public void setBtnLimpiar(CommandButton btnLimpiar) {
		this.btnLimpiar = btnLimpiar;
	}

}
