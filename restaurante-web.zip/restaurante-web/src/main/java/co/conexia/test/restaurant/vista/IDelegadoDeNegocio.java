package co.conexia.test.restaurant.vista;

import java.math.BigDecimal;
import java.util.List;

import co.conexia.test.restaurant.modelo.Camarero;
import co.conexia.test.restaurant.modelo.Cliente;
import co.conexia.test.restaurant.modelo.Cocinero;
import co.conexia.test.restaurant.modelo.Detallefactura;
import co.conexia.test.restaurant.modelo.Factura;
import co.conexia.test.restaurant.modelo.Mesa;


public interface IDelegadoDeNegocio {
	
	public void grabarCliente(Cliente cliente)throws Exception;
	public void modificarCliente(Cliente cliente)throws Exception;	
	public Cliente consultarClientePorId(int idcliente);
	public List<Cliente> consultarClienteTodos();
	
	public void grabarCamarero(Camarero camarero)throws Exception;
	public void modificarCamarero(Camarero camarero)throws Exception;
	public Camarero consultarCamareroPorId(int idcamarero);
	public List<Camarero> consultarCamareroTodos();
	
	public void grabarCocinero(Cocinero cocinero)throws Exception;
	public void modificarCocinero(Cocinero cocinero)throws Exception;
	public Cocinero consultarCocineroPorId(int idcocinero);
	public List<Cocinero> consultarCocineroTodos();
	
	public void grabarDetallefactura(Detallefactura detallefactura)throws Exception;
	public void modificarDetallefactura(Detallefactura detallefactura)throws Exception;
	public Detallefactura consultarDetallefacturaPorId(int iddetallefactura);
	public List<Detallefactura> consultarDetallefacturaTodos();
	
	public void grabarFactura(Factura factura)throws Exception;
	public void modificarFactura(Factura factura)throws Exception;
	public Factura consultarFacturaPorId(int idfactura);
	public List<Factura> consultarFacturaTodos();
	
	public void grabarMesa(Mesa mesa)throws Exception;
	public void modificarMesa(Mesa mesa)throws Exception;
	public Mesa consultarMesaPorId(int idmesa);
	public List<Mesa> consultarMesaTodos();

}
