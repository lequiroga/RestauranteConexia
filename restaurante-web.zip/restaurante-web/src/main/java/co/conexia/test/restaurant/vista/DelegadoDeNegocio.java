package co.conexia.test.restaurant.vista;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import co.conexia.test.restaurant.logica.ICamareroLogica;
import co.conexia.test.restaurant.logica.IClienteLogica;
import co.conexia.test.restaurant.logica.ICocineroLogica;
import co.conexia.test.restaurant.logica.IDetallefacturaLogica;
import co.conexia.test.restaurant.logica.IFacturaLogica;
import co.conexia.test.restaurant.logica.IMesaLogica;
import co.conexia.test.restaurant.modelo.Camarero;
import co.conexia.test.restaurant.modelo.Cliente;
import co.conexia.test.restaurant.modelo.Cocinero;
import co.conexia.test.restaurant.modelo.Detallefactura;
import co.conexia.test.restaurant.modelo.Factura;
import co.conexia.test.restaurant.modelo.Mesa;

@Component
@Scope("singleton")
public class DelegadoDeNegocio implements IDelegadoDeNegocio {
	
	@Autowired
	private IClienteLogica clienteLogica;
	
	@Autowired
	private ICamareroLogica camareroLogica;
	
	@Autowired
	private ICocineroLogica cocineroLogica;
	
	@Autowired
	private IMesaLogica mesaLogica;
	
	@Autowired
	private IFacturaLogica facturaLogica;
	
	@Autowired
	private IDetallefacturaLogica detalleFacturaLogica;

	@Override
	public void grabarCliente(Cliente cliente) throws Exception {		
		clienteLogica.grabar(cliente);
	}

	@Override
	public void modificarCliente(Cliente cliente) throws Exception {
		clienteLogica.modificar(cliente);
	}

	@Override
	public Cliente consultarClientePorId(int idcliente) {
		return clienteLogica.consultarPorId(idcliente);
	}

	@Override
	public List<Cliente> consultarClienteTodos() {
		return clienteLogica.consultarTodos();
	}

	@Override
	public void grabarCamarero(Camarero camarero) throws Exception {
		camareroLogica.grabar(camarero);
	}

	@Override
	public void modificarCamarero(Camarero camarero) throws Exception {
		camareroLogica.modificar(camarero);
	}

	@Override
	public Camarero consultarCamareroPorId(int idcamarero) {
		return camareroLogica.consultarPorId(idcamarero);
	}

	@Override
	public List<Camarero> consultarCamareroTodos() {
		return camareroLogica.consultarTodos();
	}

	@Override
	public void grabarCocinero(Cocinero cocinero) throws Exception {
		cocineroLogica.grabar(cocinero);
	}

	@Override
	public void modificarCocinero(Cocinero cocinero) throws Exception {
		cocineroLogica.modificar(cocinero);
	}

	@Override
	public Cocinero consultarCocineroPorId(int idcocinero) {		
		return cocineroLogica.consultarPorId(idcocinero);
	}

	@Override
	public List<Cocinero> consultarCocineroTodos() {		
		return cocineroLogica.consultarTodos();
	}

	@Override
	public void grabarDetallefactura(Detallefactura detallefactura) throws Exception {
		detalleFacturaLogica.grabar(detallefactura);
	}

	@Override
	public void modificarDetallefactura(Detallefactura detallefactura) throws Exception {
		detalleFacturaLogica.modificar(detallefactura);
	}

	@Override
	public Detallefactura consultarDetallefacturaPorId(int iddetallefactura) {		
		return detalleFacturaLogica.consultarPorId(iddetallefactura);
	}

	@Override
	public List<Detallefactura> consultarDetallefacturaTodos() {		
		return detalleFacturaLogica.consultarTodos();
	}

	@Override
	public void grabarFactura(Factura factura) throws Exception {
		facturaLogica.grabar(factura);
	}

	@Override
	public void modificarFactura(Factura factura) throws Exception {
		facturaLogica.modificar(factura);
	}

	@Override
	public Factura consultarFacturaPorId(int idfactura) {		
		return facturaLogica.consultarPorId(idfactura);
	}

	@Override
	public List<Factura> consultarFacturaTodos() {		
		return facturaLogica.consultarTodos();
	}

	@Override
	public void grabarMesa(Mesa mesa) throws Exception {
		mesaLogica.grabar(mesa);
	}

	@Override
	public void modificarMesa(Mesa mesa) throws Exception {
		mesaLogica.modificar(mesa);
	}

	@Override
	public Mesa consultarMesaPorId(int idmesa) {		
		return mesaLogica.consultarPorId(idmesa);
	}

	@Override
	public List<Mesa> consultarMesaTodos() {		
		return mesaLogica.consultarTodos();
	}

}
