package co.conexia.test.restaurant.logica;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.conexia.test.restaurant.dao.IDetallefacturaDAO;
import co.conexia.test.restaurant.modelo.Detallefactura;

@Service
@Scope("singleton")
public class DetallefacturaLogicaImpl implements IDetallefacturaLogica {
	
	@Autowired
	private IDetallefacturaDAO detallefacturaDAO;
	
	@Autowired
	private Validator validator;
	
	public void validarDetallefacturas(Detallefactura detallefactura) throws Exception {
	    try {
	        Set<ConstraintViolation<Detallefactura>> constraintViolations = validator.validate(detallefactura);

	        if (constraintViolations.size() > 0) {
	            StringBuilder strMessage = new StringBuilder();

	            for (ConstraintViolation<Detallefactura> constraintViolation : constraintViolations) {
	                strMessage.append(constraintViolation.getPropertyPath()
	                                                     .toString());
	                strMessage.append(" - ");
	                strMessage.append(constraintViolation.getMessage());
	                strMessage.append(". \n");
	            }

	            throw new Exception(strMessage.toString());
	        }
	    } catch (Exception e) {
	        throw e;
	    }
	}

	@Override
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	public void grabar( Detallefactura detallefactura) throws Exception {
		if(detallefactura==null) {
			throw new Exception("La detallefactura es nula");
		}
		
		validarDetallefacturas(detallefactura);
		
		detallefacturaDAO.grabar(detallefactura);
	}

	@Override
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	public void modificar(Detallefactura detallefactura) throws Exception {
		if(detallefactura==null) {
			throw new Exception("La detallefactura es nula");
		}
		
		validarDetallefacturas(detallefactura);
		
		detallefacturaDAO.modificar(detallefactura);
	}
	
	@Override
	@Transactional(readOnly=true)
	public Detallefactura consultarPorId(int iddetallefactura) {
		return detallefacturaDAO.consultarPorId(iddetallefactura);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Detallefactura> consultarTodos() {
		return detallefacturaDAO.consultarTodos();
	}
	
}
