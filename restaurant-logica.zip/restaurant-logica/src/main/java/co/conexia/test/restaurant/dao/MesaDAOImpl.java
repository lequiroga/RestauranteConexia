package co.conexia.test.restaurant.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import co.conexia.test.restaurant.modelo.Mesa;

@Repository
@Scope("singleton")
public class MesaDAOImpl implements IMesaDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void grabar(Mesa mesa) {
		entityManager.persist(mesa);

	}

	@Override
	public void modificar(Mesa mesa) {
		entityManager.merge(mesa);

	}

	@Override
	public Mesa consultarPorId(int idmesa) {

		return entityManager.find(Mesa.class, idmesa);
	}

	@Override
	public List<Mesa> consultarTodos() {
		// TODO Auto-generated method stub
		return entityManager.createQuery(
				  "SELECT "+
				    "m "+
				  "FROM "+
				    "mesa m").getResultList();
	}

}
