package co.conexia.test.restaurant.logica;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.conexia.test.restaurant.dao.ICocineroDAO;
import co.conexia.test.restaurant.modelo.Cocinero;

@Service
@Scope("singleton")
public class CocineroLogicaImpl implements ICocineroLogica {
	
	@Autowired
	private ICocineroDAO cocineroDAO;
	
	@Autowired
	private Validator validator;
	
	public void validarCocineros(Cocinero cocinero) throws Exception {
	    try {
	        Set<ConstraintViolation<Cocinero>> constraintViolations = validator.validate(cocinero);

	        if (constraintViolations.size() > 0) {
	            StringBuilder strMessage = new StringBuilder();

	            for (ConstraintViolation<Cocinero> constraintViolation : constraintViolations) {
	                strMessage.append(constraintViolation.getPropertyPath()
	                                                     .toString());
	                strMessage.append(" - ");
	                strMessage.append(constraintViolation.getMessage());
	                strMessage.append(". \n");
	            }

	            throw new Exception(strMessage.toString());
	        }
	    } catch (Exception e) {
	        throw e;
	    }
	}

	@Override
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	public void grabar( Cocinero cocinero) throws Exception {
		if(cocinero==null) {
			throw new Exception("El cocinero es nulo");
		}
		
		validarCocineros(cocinero);
		
		cocineroDAO.grabar(cocinero);
	}

	@Override
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	public void modificar(Cocinero cocinero) throws Exception {
		if(cocinero==null) {
			throw new Exception("El cocinero es nulo");
		}
		
		validarCocineros(cocinero);
		
		cocineroDAO.modificar(cocinero);
	}
	
	@Override
	@Transactional(readOnly=true)
	public Cocinero consultarPorId(int idcocinero) {
		return cocineroDAO.consultarPorId(idcocinero);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Cocinero> consultarTodos() {
		return cocineroDAO.consultarTodos();
	}

}
