package co.conexia.test.restaurant.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import co.conexia.test.restaurant.modelo.Cliente;

@Repository
@Scope("singleton")
public class ClienteDAOImpl implements IClienteDAO {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void grabar(Cliente cliente) {
		entityManager.persist(cliente);
	}

	@Override
	public void modificar(Cliente cliente) {
		entityManager.merge(cliente);
	}

	@Override
	public Cliente consultarPorId(int idcliente) {		
		return entityManager.find(Cliente.class, idcliente);
	}

	@Override
	public List<Cliente> consultarTodos() {		
		return entityManager.createQuery("SELECT c FROM Cliente c").getResultList(); 
	}

}
