package co.conexia.test.restaurant.dao;

import java.util.List;

import co.conexia.test.restaurant.modelo.Cliente;

public interface IClienteDAO {
	
	public void grabar(Cliente cliente);
	public void modificar(Cliente cliente);
	public Cliente consultarPorId(int idcliente);
	public List<Cliente> consultarTodos();

}
