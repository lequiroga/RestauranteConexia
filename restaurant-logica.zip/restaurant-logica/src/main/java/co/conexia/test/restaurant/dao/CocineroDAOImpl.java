package co.conexia.test.restaurant.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import co.conexia.test.restaurant.modelo.Cocinero;

@Repository
@Scope("singleton")
public class CocineroDAOImpl implements ICocineroDAO {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void grabar(Cocinero cocinero) {
		entityManager.persist(cocinero);
	}

	@Override
	public void modificar(Cocinero cocinero) {
		entityManager.merge(cocinero);
	}

	@Override
	public Cocinero consultarPorId(int idcocinero) {		
		return entityManager.find(Cocinero.class, idcocinero);
	}

	@Override
	public List<Cocinero> consultarTodos() {		
		return entityManager.createQuery("SELECT coc FROM cocinero coc").getResultList();
	}

}
