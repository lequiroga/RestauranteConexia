package co.conexia.test.restaurant.logica;

import java.util.List;

import co.conexia.test.restaurant.modelo.Detallefactura;

public interface IDetallefacturaLogica {
	
	public void grabar(Detallefactura detallefactura)throws Exception;
	public void modificar(Detallefactura detallefactura)throws Exception;
	public Detallefactura consultarPorId(int iddetallefactura);
	public List<Detallefactura> consultarTodos();

}
