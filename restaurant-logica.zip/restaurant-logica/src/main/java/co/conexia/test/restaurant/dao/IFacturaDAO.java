package co.conexia.test.restaurant.dao;

import java.util.List;

import co.conexia.test.restaurant.modelo.Factura;

public interface IFacturaDAO {
	
	public void grabar(Factura factura);
	public void modificar(Factura factura);
	public Factura consultarPorId(int idfactura);
	public List<Factura> consultarTodos();

}
