package co.conexia.test.restaurant.dao;

import java.util.List;

import co.conexia.test.restaurant.modelo.Mesa;

public interface IMesaDAO {
	
	public void grabar(Mesa mesa);
	public void modificar(Mesa mesa);
	public Mesa consultarPorId(int idmesa);
	public List<Mesa> consultarTodos();

}
