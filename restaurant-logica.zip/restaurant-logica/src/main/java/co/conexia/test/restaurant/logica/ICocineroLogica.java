package co.conexia.test.restaurant.logica;

import java.util.List;

import co.conexia.test.restaurant.modelo.Cocinero;

public interface ICocineroLogica {
	
	public void grabar(Cocinero cocinero)throws Exception;
	public void modificar(Cocinero cocinero)throws Exception;
	public Cocinero consultarPorId(int idcocinero);
	public List<Cocinero> consultarTodos();

}
