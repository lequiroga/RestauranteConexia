package co.conexia.test.restaurant.logica;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.conexia.test.restaurant.dao.IMesaDAO;
import co.conexia.test.restaurant.modelo.Mesa;

@Service
@Scope("singleton")
public class MesaLogicaImpl implements IMesaLogica {
	
	@Autowired
	private IMesaDAO mesaDAO;
	
	@Autowired
	private Validator validator;
	
	public void validarMesas(Mesa mesa) throws Exception {
	    try {
	        Set<ConstraintViolation<Mesa>> constraintViolations = validator.validate(mesa);

	        if (constraintViolations.size() > 0) {
	            StringBuilder strMessage = new StringBuilder();

	            for (ConstraintViolation<Mesa> constraintViolation : constraintViolations) {
	                strMessage.append(constraintViolation.getPropertyPath()
	                                                     .toString());
	                strMessage.append(" - ");
	                strMessage.append(constraintViolation.getMessage());
	                strMessage.append(". \n");
	            }

	            throw new Exception(strMessage.toString());
	        }
	    } catch (Exception e) {
	        throw e;
	    }
	}

	@Override
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	public void grabar( Mesa mesa) throws Exception {
		if(mesa==null) {
			throw new Exception("La mesa es nula");
		}
		
		validarMesas(mesa);
		
		mesaDAO.grabar(mesa);
	}

	@Override
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	public void modificar(Mesa mesa) throws Exception {
		if(mesa==null) {
			throw new Exception("La mesa es nula");
		}
		
		validarMesas(mesa);
		
		mesaDAO.modificar(mesa);
	}
	
	@Override
	@Transactional(readOnly=true)
	public Mesa consultarPorId(int idmesa) {
		return mesaDAO.consultarPorId(idmesa);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Mesa> consultarTodos() {
		return mesaDAO.consultarTodos();
	}
	
}
