package co.conexia.test.restaurant.logica;

import java.util.List;

import co.conexia.test.restaurant.modelo.Cliente;

public interface IClienteLogica {
	
	public void grabar(Cliente cliente)throws Exception;
	public void modificar(Cliente cliente)throws Exception;
	public Cliente consultarPorId(int idcliente);
	public List<Cliente> consultarTodos();

}
