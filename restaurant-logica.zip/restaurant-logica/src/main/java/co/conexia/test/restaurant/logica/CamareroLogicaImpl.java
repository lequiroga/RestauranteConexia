package co.conexia.test.restaurant.logica;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.conexia.test.restaurant.dao.ICamareroDAO;
import co.conexia.test.restaurant.modelo.Camarero;

@Service
@Scope("singleton")
public class CamareroLogicaImpl implements ICamareroLogica {
	
	@Autowired
	private ICamareroDAO camareroDAO;
	
	@Autowired
	private Validator validator;
	
	public void validarCamareros(Camarero camarero) throws Exception {
	    try {
	        Set<ConstraintViolation<Camarero>> constraintViolations = validator.validate(camarero);

	        if (constraintViolations.size() > 0) {
	            StringBuilder strMessage = new StringBuilder();

	            for (ConstraintViolation<Camarero> constraintViolation : constraintViolations) {
	                strMessage.append(constraintViolation.getPropertyPath()
	                                                     .toString());
	                strMessage.append(" - ");
	                strMessage.append(constraintViolation.getMessage());
	                strMessage.append(". \n");
	            }

	            throw new Exception(strMessage.toString());
	        }
	    } catch (Exception e) {
	        throw e;
	    }
	}

	@Override
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	public void grabar( Camarero camarero) throws Exception {
		if(camarero==null) {
			throw new Exception("El camarero es nulo");
		}
		
		validarCamareros(camarero);
		
		camareroDAO.grabar(camarero);
	}

	@Override
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	public void modificar(Camarero camarero) throws Exception {
		if(camarero==null) {
			throw new Exception("El camarero es nulo");
		}
		
		validarCamareros(camarero);
		
		camareroDAO.modificar(camarero);
	}
	
	@Override
	@Transactional(readOnly=true)
	public Camarero consultarPorId(int idcamarero) {
		return camareroDAO.consultarPorId(idcamarero);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Camarero> consultarTodos() {
		return camareroDAO.consultarTodos();
	}

}
