package co.conexia.test.restaurant.logica;

import java.util.List;
import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import co.conexia.test.restaurant.dao.IFacturaDAO;
import co.conexia.test.restaurant.modelo.Factura;

@Service
@Scope("singleton")
public class FacturaLogicaImpl implements IFacturaLogica {
	
	@Autowired
	private IFacturaDAO facturaDAO;
	
	@Autowired
	private Validator validator;
	
	public void validarFacturas(Factura factura) throws Exception {
	    try {
	        Set<ConstraintViolation<Factura>> constraintViolations = validator.validate(factura);

	        if (constraintViolations.size() > 0) {
	            StringBuilder strMessage = new StringBuilder();

	            for (ConstraintViolation<Factura> constraintViolation : constraintViolations) {
	                strMessage.append(constraintViolation.getPropertyPath()
	                                                     .toString());
	                strMessage.append(" - ");
	                strMessage.append(constraintViolation.getMessage());
	                strMessage.append(". \n");
	            }

	            throw new Exception(strMessage.toString());
	        }
	    } catch (Exception e) {
	        throw e;
	    }
	}

	@Override
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	public void grabar( Factura factura) throws Exception {
		if(factura==null) {
			throw new Exception("La factura es nula");
		}
		
		validarFacturas(factura);
		
		facturaDAO.grabar(factura);
	}

	@Override
	@Transactional(readOnly=false,propagation=Propagation.REQUIRED,rollbackFor=Exception.class)
	public void modificar(Factura factura) throws Exception {
		if(factura==null) {
			throw new Exception("La factura es nula");
		}
		
		validarFacturas(factura);
		
		facturaDAO.modificar(factura);
	}
	
	@Override
	@Transactional(readOnly=true)
	public Factura consultarPorId(int idfactura) {
		return facturaDAO.consultarPorId(idfactura);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Factura> consultarTodos() {
		return facturaDAO.consultarTodos();
	}
	
}
