package co.conexia.test.restaurant.dao;

import java.util.List;

import co.conexia.test.restaurant.modelo.Detallefactura;
import co.conexia.test.restaurant.modelo.Factura;

public interface IDetallefacturaDAO {
	
	public void grabar(Detallefactura detallefactura);
	public void modificar(Detallefactura detallefactura);
	public Detallefactura consultarPorId(int iddetallefactura);
	public List<Detallefactura> consultarTodos();

}
