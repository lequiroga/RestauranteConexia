package co.conexia.test.restaurant.logica;

import java.util.List;

import co.conexia.test.restaurant.modelo.Factura;

public interface IFacturaLogica {
	
	public void grabar(Factura factura)throws Exception;
	public void modificar(Factura factura)throws Exception;
	public Factura consultarPorId(int idfactura);
	public List<Factura> consultarTodos();

}
