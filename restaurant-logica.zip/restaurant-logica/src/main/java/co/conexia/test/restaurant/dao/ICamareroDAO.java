package co.conexia.test.restaurant.dao;

import java.util.List;

import co.conexia.test.restaurant.modelo.Camarero;

public interface ICamareroDAO {
	
	public void grabar(Camarero cliente);
	public void modificar(Camarero cliente);
	public Camarero consultarPorId(int idcamarero);
	public List<Camarero> consultarTodos();

}
