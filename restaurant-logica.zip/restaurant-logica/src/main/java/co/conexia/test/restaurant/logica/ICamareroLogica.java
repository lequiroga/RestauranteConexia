package co.conexia.test.restaurant.logica;

import java.util.List;

import co.conexia.test.restaurant.modelo.Camarero;

public interface ICamareroLogica {
	
	public void grabar(Camarero camarero)throws Exception;
	public void modificar(Camarero camarero)throws Exception;
	public Camarero consultarPorId(int idcamarero);
	public List<Camarero> consultarTodos();

}
