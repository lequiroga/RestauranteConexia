package co.conexia.test.restaurant.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import co.conexia.test.restaurant.modelo.Camarero;

@Repository
@Scope("singleton")
public class CamareroDAOImpl implements ICamareroDAO {
	
	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void grabar(Camarero camarero) {
		entityManager.persist(camarero);
	}

	@Override
	public void modificar(Camarero camarero) {
		entityManager.merge(camarero);
	}

	@Override
	public Camarero consultarPorId(int idcamarero) {		
		return entityManager.find(Camarero.class, idcamarero);
	}

	@Override
	public List<Camarero> consultarTodos() {		
		return entityManager.createQuery("SELECT cam FROM Camarero cam").getResultList();
	}

}
