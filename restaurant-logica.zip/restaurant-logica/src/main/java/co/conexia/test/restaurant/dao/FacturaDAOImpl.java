package co.conexia.test.restaurant.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import co.conexia.test.restaurant.modelo.Factura;

@Repository
@Scope("singleton")
public class FacturaDAOImpl implements IFacturaDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void grabar(Factura factura) {
		entityManager.persist(factura);

	}

	@Override
	public void modificar(Factura factura) {
		entityManager.merge(factura);

	}

	@Override
	public Factura consultarPorId(int idfactura) {

		return entityManager.find(Factura.class, idfactura);
	}

	@Override
	public List<Factura> consultarTodos() {
		// TODO Auto-generated method stub
		return entityManager.createQuery(
				  "SELECT "+
				    "f "+
				  "FROM "+
				    "factura f").getResultList();
	}

}
