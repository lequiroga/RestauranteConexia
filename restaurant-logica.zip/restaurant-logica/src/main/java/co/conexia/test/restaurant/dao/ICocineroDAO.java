package co.conexia.test.restaurant.dao;

import java.util.List;

import co.conexia.test.restaurant.modelo.Camarero;
import co.conexia.test.restaurant.modelo.Cocinero;

public interface ICocineroDAO {
	
	public void grabar(Cocinero cocinero);
	public void modificar(Cocinero cocinero);
	public Cocinero consultarPorId(int idcocinero);
	public List<Cocinero> consultarTodos();

}
