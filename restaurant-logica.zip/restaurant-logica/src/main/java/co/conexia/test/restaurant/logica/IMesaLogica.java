package co.conexia.test.restaurant.logica;

import java.util.List;

import co.conexia.test.restaurant.modelo.Mesa;

public interface IMesaLogica {
	
	public void grabar(Mesa mesa)throws Exception;
	public void modificar(Mesa mesa)throws Exception;
	public Mesa consultarPorId(int idmesa);
	public List<Mesa> consultarTodos();

}
