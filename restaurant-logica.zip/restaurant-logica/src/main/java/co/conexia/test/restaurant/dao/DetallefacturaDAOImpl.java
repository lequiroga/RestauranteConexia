package co.conexia.test.restaurant.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Repository;

import co.conexia.test.restaurant.modelo.Detallefactura;

@Repository
@Scope("singleton")
public class DetallefacturaDAOImpl implements IDetallefacturaDAO {

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public void grabar(Detallefactura detallefactura) {
		entityManager.persist(detallefactura);

	}

	@Override
	public void modificar(Detallefactura detallefactura) {
		entityManager.merge(detallefactura);

	}

	@Override
	public Detallefactura consultarPorId(int iddetallefactura) {

		return entityManager.find(Detallefactura.class, iddetallefactura);
	}

	@Override
	public List<Detallefactura> consultarTodos() {
		// TODO Auto-generated method stub
		return entityManager.createQuery(
				  "SELECT "+
				    "f "+
				  "FROM "+
				    "detallefactura f").getResultList();
	}

}
